### `jsoncons::basic_json::basic_json`

```c++
~basic_json() noexcept;
```

Destroys all values and deletes all memory allocated for strings, arrays, and objects.


