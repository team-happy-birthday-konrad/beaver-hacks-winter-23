### jsoncons::indenting

```c++
#include <jsoncons/json_options.hpp>

enum class indenting {no_indent, indent}
```

Specifies indentation options for the [basic_json_encoder](basic_json_encoder.md)

