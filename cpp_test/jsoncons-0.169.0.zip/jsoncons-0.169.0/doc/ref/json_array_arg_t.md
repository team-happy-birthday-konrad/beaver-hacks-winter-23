### jsoncons::json_array_arg_t 

#include <jsoncons/tag_type.hpp`__

```c++
struct json_array_arg_t {explicit json_array_arg_t() = default;};
```

`json_array_arg_t` is an empty class type used to disambiguate constructor overloads for json arrays.

### See also

[json_array_arg](json_array_arg.md)
