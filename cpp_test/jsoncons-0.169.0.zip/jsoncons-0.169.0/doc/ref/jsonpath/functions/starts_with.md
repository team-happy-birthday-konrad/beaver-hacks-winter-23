### starts_with

```
boolean starts_with(string source, string prefix)
```

Returns true if the source string starts with the prefix string, otherwise false.

It is a type error if 

- the provided source is not a string, or
- the provided prefix is not a string

### Examples


